import org.junit.Test;

import cs3500.hw02.FreecellOperations;
import cs3500.hw04.FreecellModelCreator;

/**
 * Tests when you give a freecellcreator neither of the specified game types
 * Created by Tim on 6/3/2017.
 */
public class FreecellCreatorTest {
  private FreecellModelCreator creator = new FreecellModelCreator();
  private FreecellOperations game;

  @Test(expected = NullPointerException.class)
  public void nullGameTypeTest() {
    game = creator.create(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void randomGameTypeTest() {
    game = creator.create(FreecellModelCreator.GameType.valueOf("Nonexistant value."));
  }
}
