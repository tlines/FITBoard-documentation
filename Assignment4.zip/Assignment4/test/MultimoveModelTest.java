import org.junit.Before;
import org.junit.Test;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellOperations;
import cs3500.hw02.PileType;
import cs3500.hw02.Suit;
import cs3500.hw04.FreecellModelCreator;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Created by Tim on 6/3/2017.
 * Tests Multimovemodel and freecellmodelcreator
 */
public class MultimoveModelTest {
  private FreecellModelCreator creator = new FreecellModelCreator();
  private FreecellOperations game;
  private List<Card> normalDeck;
  private List<Card> dupDeck;
  private List<Card> bigDeck;
  private String normalString;

  /**
   * creates objects listed above. won't work for testing if set to private.
   */
  @Before
  public void helper() throws Exception {
    game = creator.create(FreecellModelCreator.GameType.MULTIMOVE);
    normalDeck = game.getDeck();

    dupDeck = game.getDeck();
    dupDeck.set(0, new Card(13, Suit.SPADES));

    bigDeck = game.getDeck();
    bigDeck.add(new Card(13,Suit.SPADES));

    normalString = "[A♣, 2♣, 3♣, 4♣, 5♣, 6♣, 7♣, 8♣, 9♣, 10♣, J♣, Q♣, K♣, "
            + "A♦, 2♦, 3♦, 4♦, 5♦, 6♦, 7♦, 8♦, 9♦, 10♦, J♦, Q♦, K♦, "
            + "A♥, 2♥, 3♥, 4♥, 5♥, 6♥, 7♥, 8♥, 9♥, 10♥, J♥, Q♥, K♥, "
            + "A♠, 2♠, 3♠, 4♠, 5♠, 6♠, 7♠, 8♠, 9♠, 10♠, J♠, Q♠, K♠]";
  }

  @Test
  public void toStringTest() {
    assertEquals(normalString, normalDeck.toString());
  }

  @Test
  public void isGameOverFalseTest() {
    game.startGame(game.getDeck(), 5, 3, false);
    assertEquals(false, game.isGameOver());
  }

  @Test
  public void getGameStateTest() {
    String expected = "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠, Q♠\n"
            + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
            + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
            + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
            + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠";
    game.startGame(normalDeck, 5, 3, false);
    assertEquals(expected, game.getGameState());
  }

  @Test
  public void getGameStateShuffleTest() {
    String expected = "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠, Q♠\n"
            + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
            + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
            + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
            + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠";

    game.startGame(game.getDeck(),5,3,true);
    assertNotEquals(expected,game.getGameState());
  }

  @Test
  public void emptyGameStateTest() {
    assertEquals("", game.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void dupDeckShuffleTest() {
    game.startGame(dupDeck,5,3,true);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void dupDeckNoShuffleTest() {
    game.startGame(dupDeck,8,4,false);
  }


  @Test(expected = IllegalArgumentException.class)
  public void bigDeckShuffleTest() {
    game.startGame(bigDeck,5,3,true);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void bigDeckNoShuffleTest() {
    game.startGame(bigDeck,5,3,false);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void openToCascadetest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.OPEN, 0, 0, PileType.CASCADE, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void cascadeToCascadeFailtest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 10, PileType.CASCADE, 4);
    assertEquals(game.getGameState(), "");
  }

  @Test
  public void cascadeToOpenTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 10, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1: Q♠\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠\n"
            + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
            + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
            + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
            + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠");
  }

  @Test(expected = IllegalArgumentException.class)
  public void cascadeToOpenTwiceTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 10, PileType.OPEN, 0);
    game.move(PileType.CASCADE, 0, 10, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test
  public void opentoOpenTest() {
    game.startGame(game.getDeck(),52,2,false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 1);
    game.move(PileType.OPEN, 1, 0, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1: A♣\n"
            + "O2:\n"
            + "C1:\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠");
  }

  @Test
  public void openToFoundationtest() {
    game.startGame(game.getDeck(),52,2,false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    game.move(PileType.OPEN, 0, 0, PileType.FOUNDATION, 0);
    assertEquals(game.getGameState(), "F1: A♣\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "C1:\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠");
  }

  @Test
  public void foundationToOpenTest() {
    game.startGame(game.getDeck(),52,2,false);
    game.move(PileType.CASCADE, 0, 0, PileType.FOUNDATION, 0);
    game.move(PileType.FOUNDATION, 0, 0, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1: A♣\n"
            + "O2:\n"
            + "C1:\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠");
  }

  @Test
  public void cascadeToFoundationTest() {
    game.startGame(game.getDeck(),52,2,false);
    game.move(PileType.CASCADE, 0, 0, PileType.FOUNDATION, 0);
    assertEquals(game.getGameState(), "F1: A♣\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "C1:\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠");
  }

  @Test
  public void foundationToCascadeTest() {
    game.startGame(game.getDeck(),52,2,false);
    game.move(PileType.CASCADE, 0,0, PileType.FOUNDATION,0);
    game.move(PileType.FOUNDATION, 0, 0, PileType.CASCADE, 0);
    assertEquals(game.getGameState(), "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠");
  }

  @Test
  public void multiMoveTest() {
    game.startGame(game.getDeck(), 52, 2, false);
    game.move(PileType.CASCADE, 0, 0, PileType.CASCADE, 14);
    game.move(PileType.CASCADE, 14, 0, PileType.CASCADE, 2);
    assertEquals(game.getGameState(), "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "C1:\n"
            + "C2: 2♣\n"
            + "C3: 3♣, 2♦, A♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15:\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠");
  }

  @Test(expected = IllegalArgumentException.class)
  public void multiMoveTooManyCardsTest() {
    game.startGame(game.getDeck(), 26, 2, false);
    game.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    game.move(PileType.CASCADE, 14, 1, PileType.CASCADE, 2);
    game.move(PileType.CASCADE, 2, 1, PileType.CASCADE, 16);
    game.move(PileType.CASCADE, 16, 1, PileType.CASCADE, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void multiMoveIllegalTest() {
    game.startGame(game.getDeck(), 26, 2, false);
    game.move(PileType.CASCADE, 0, 0, PileType.CASCADE, 14);
  }

  @Test(expected = IllegalArgumentException.class)
  public void multiMoveIllegalCtoOTest() {
    game.startGame(game.getDeck(), 26, 2, false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void multiMoveIllegalCtoFTest() {
    game.startGame(game.getDeck(), 26, 2, false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void destOutOfBoundsTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 10, PileType.OPEN, 4);
  }

  @Test(expected = IndexOutOfBoundsException.class)
  public void sourceOutOfBoundsTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 6, 0, PileType.OPEN, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void indexOutOfBoundsTest() {
    game.startGame(game.getDeck(),8,3,false);
    game.move(PileType.CASCADE, 6, 8, PileType.OPEN, 2);
  }
}