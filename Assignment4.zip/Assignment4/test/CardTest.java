import org.junit.Test;

import cs3500.hw02.Suit;
import cs3500.hw02.Card;

import static org.junit.Assert.assertEquals;

/**
 * Created by Tim on 5/19/2017.
 */
public class CardTest {
  Card kingofdiamonds = new Card(13, Suit.DIAMONDS);
  Card nineofhearts = new Card(9, Suit.HEARTS);
  Card aceofspades = new Card(1, Suit.SPADES);
  Card fourofclubs = new Card(4, Suit.CLUBS);

  @Test
  public void KDtest() {
    assertEquals("K♦", kingofdiamonds.toString());
  }

  @Test
  public void NINEHtest() {
    assertEquals("9♥", nineofhearts.toString());
  }

  @Test
  public void AStest() {
    assertEquals("A♠", aceofspades.toString());
  }

  @Test
  public void FOURCtest() {
    assertEquals("4♣", fourofclubs.toString());
  }
}