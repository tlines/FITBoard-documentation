import org.junit.Before;
import org.junit.Test;

import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.PileType;
import cs3500.hw02.Suit;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Created by Tim on 5/19/2017.
 * Tests FreecellModel, first by creating a model, then attempting methods in the class
 * using different parameters.
 */
public class FreecellModelTest {
  private FreecellModel game;
  private List<Card> normalDeck;
  private List<Card> dupDeck;
  private List<Card> bigDeck;
  private String normalString;

  /**
   * creates objects listed above. won't work for testing if set to private.
   */
  @Before
  public void helper() throws Exception {
    game = new FreecellModel();
    normalDeck = game.getDeck();

    dupDeck = game.getDeck();
    dupDeck.set(0, new Card(13, Suit.SPADES));

    bigDeck = game.getDeck();
    bigDeck.add(new Card(13,Suit.SPADES));

    normalString = "[A♣, 2♣, 3♣, 4♣, 5♣, 6♣, 7♣, 8♣, 9♣, 10♣, J♣, Q♣, K♣, "
            + "A♦, 2♦, 3♦, 4♦, 5♦, 6♦, 7♦, 8♦, 9♦, 10♦, J♦, Q♦, K♦, "
            + "A♥, 2♥, 3♥, 4♥, 5♥, 6♥, 7♥, 8♥, 9♥, 10♥, J♥, Q♥, K♥, "
            + "A♠, 2♠, 3♠, 4♠, 5♠, 6♠, 7♠, 8♠, 9♠, 10♠, J♠, Q♠, K♠]";
  }

  @Test
  public void toStringTest() {
    assertEquals(normalString, normalDeck.toString());
  }

  @Test
  public void isGameOverFalseTest() {
    game.startGame(game.getDeck(), 5, 3, false);
    assertEquals(false, game.isGameOver());
  }

  @Test
  public void isGameOverTrueTest() {
    game.startGame(game.getDeck(), 5, 3, false);
    game.finishGame();
    assertEquals(true, game.isGameOver());
  }

  @Test
  public void getGameStateTest() {
    String expected = "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠, Q♠\n"
            + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
            + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
            + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
            + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠";
    game.startGame(normalDeck, 5, 3, false);
    assertEquals(expected, game.getGameState());
  }

  @Test
  public void getGameStateShuffleTest() {
    String expected = "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠, Q♠\n"
            + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
            + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
            + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
            + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠";

    game.startGame(game.getDeck(),5,3,true);
    assertNotEquals(expected,game.getGameState());
  }

  @Test
  public void emptyGameStateTest() {
    assertEquals("", game.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void dupDeckShuffleTest() {
    game.startGame(dupDeck,5,3,true);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void dupDeckNoShuffleTest() {
    game.startGame(dupDeck,8,4,false);
  }


  @Test(expected = IllegalArgumentException.class)
  public void bigDeckShuffleTest() {
    game.startGame(bigDeck,5,3,true);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void bigDeckNoShuffleTest() {
    game.startGame(bigDeck,5,3,false);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void openToCascadetest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.OPEN, 0, 0, PileType.CASCADE, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void cascadeToCascadetest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 10, PileType.CASCADE, 5);
    assertEquals(game.getGameState(), "");
  }

  @Test
  public void cascadeToOpenTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 10, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "F1:\n"
                    + "F2:\n"
                    + "F3:\n"
                    + "F4:\n"
                    + "O1: Q♠\n"
                    + "O2:\n"
                    + "O3:\n"
                    + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠\n"
                    + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
                    + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
                    + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
                    + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠");
  }

  @Test(expected = IllegalArgumentException.class)
  public void cascadeToOpenTwiceTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    game.move(PileType.CASCADE, 0, 0, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void opentoOpenTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.OPEN, 0, 0, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void openToFoundationtest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.OPEN, 0, 0, PileType.FOUNDATION, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void foundationToOpenTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.FOUNDATION, 0, 0, PileType.OPEN, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void cascadeToFoundationTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 11, PileType.FOUNDATION, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void foundationToCascadeTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.FOUNDATION, 0, 0, PileType.CASCADE, 0);
    assertEquals(game.getGameState(), "");
  }

  @Test(expected = IllegalArgumentException.class)
  public void destOutOfBoundsTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 0, 11, PileType.OPEN, 4);
  }

  @Test(expected = IndexOutOfBoundsException.class)
  public void sourceOutOfBoundsTest() {
    game.startGame(game.getDeck(),5,3,false);
    game.move(PileType.CASCADE, 6, 10, PileType.OPEN, 2);
  }
}