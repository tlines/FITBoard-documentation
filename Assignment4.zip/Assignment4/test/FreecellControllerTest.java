import org.junit.Test;
import java.io.StringReader;
import java.io.StringWriter;
import cs3500.hw03.FreecellController;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Created by Tim on 5/26/2017.
 * Tests as many cases that could occur for methods within FreecellController
 * as I could think of. This requires giving a controller a readable string to
 * accept commands from, and testing if that string is valid, and if the results
 * of a given list of commands are what we expect.
 */
public class FreecellControllerTest {

  @Test (expected = IllegalStateException.class)
  public void testInitControllerRdApNull() {
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(null, ap);
    controller.initGame();

    assertEquals(ap.toString(), "");
  }

  @Test
  public void testInitControllerModelDeckNull() {
    String in = "5 3 n q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);

    assertEquals(ap.toString(), "");
  }

  @Test
  public void testInitControllerNoShuffle() {
    String in = "5 3 n q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
        + "F1:\n"
        + "F2:\n"
        + "F3:\n"
        + "F4:\n"
        + "O1:\n"
        + "O2:\n"
        + "O3:\n"
        + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠, Q♠\n"
        + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
        + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
        + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
        + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠\n"
        + "Source Pile (F1, C2, O3, etc.): \n"
        + "Game quit prematurely.");
  }

  @Test
  public void testInitControllerShuffle() {
    String in = "5 3 y q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertNotEquals(ap.toString(), "Number of Cascade Piles: Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣, 6♣, J♣, 3♦, 8♦, K♦, 5♥, 10♥, 2♠, 7♠, Q♠\n"
            + "C2: 2♣, 7♣, Q♣, 4♦, 9♦, A♥, 6♥, J♥, 3♠, 8♠, K♠\n"
            + "C3: 3♣, 8♣, K♣, 5♦, 10♦, 2♥, 7♥, Q♥, 4♠, 9♠\n"
            + "C4: 4♣, 9♣, A♦, 6♦, J♦, 3♥, 8♥, K♥, 5♠, 10♠\n"
            + "C5: 5♣, 10♣, 2♦, 7♦, Q♦, 4♥, 9♥, A♠, 6♠, J♠\n"
            + "Source Pile (F1, C2, O3, etc.): \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testInitControllerBadCascade() {
    String in = "3 3 n q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
                    + "Please provide a number greater than or equal to 4: "
                    + "Please provide a number greater than or equal to 4: "
                    + "Please provide a number greater than or equal to 4: \n"
        + "Game quit prematurely.");
  }

  @Test
  public void testInitControllerBadOpen() {
    String in = "5 0 n q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Please provide a number greater than or equal to 1: "
            + "Please provide a number greater than or equal to 1: \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testInitControllerBadShuffle() {
    String in = "5 3 x q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): "
            + "Please just type a 'y' or an 'n': \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testInitControllerHugeCascadeNoShuffle() {
    String in = "53 3 n q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testInitControllerHugeCascadeShuffle() {
    String in = "53 3 y q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertNotEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testMoveCascadetoOpenNoShuffle() {
    String in = "53 3 n C1 1 C53 q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Card Number: "
            + "Destination Pile (F1, C2, O3, etc.): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1:\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53: A♣\n"
            + "Source Pile (F1, C2, O3, etc.): \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testQuitOnSource() {
    String in = "53 3 n q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testQuitOnIndex() {
    String in = "53 3 n C1 q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Card Number: \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testQuitOnDest() {
    String in = "53 3 n C1 1 q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Card Number: "
            + "Destination Pile (F1, C2, O3, etc.): \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testBadSource() {
    String in = "53 3 n D12 q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Please give a valid pile input: \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testBadIndex0() {
    String in = "53 3 n C1 0 q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Card Number: "
            + "Please give a valid card number: \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testBadIndexA() {
    String in = "53 3 n C1 a q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Card Number: "
            + "Please give a valid card number: \n"
            + "Game quit prematurely.");
  }

  @Test
  public void testBadDestination() {
    String in = "53 3 n C1 1 D12 q";
    Readable rd = new StringReader(in);
    Appendable ap = new StringWriter();
    FreecellController controller = new FreecellController(rd, ap);
    controller.initGame();

    assertEquals(ap.toString(), "Number of Cascade Piles: "
            + "Number of Open Piles: "
            + "Would you like to shuffle? (y/n): \n"
            + "F1:\n"
            + "F2:\n"
            + "F3:\n"
            + "F4:\n"
            + "O1:\n"
            + "O2:\n"
            + "O3:\n"
            + "C1: A♣\n"
            + "C2: 2♣\n"
            + "C3: 3♣\n"
            + "C4: 4♣\n"
            + "C5: 5♣\n"
            + "C6: 6♣\n"
            + "C7: 7♣\n"
            + "C8: 8♣\n"
            + "C9: 9♣\n"
            + "C10: 10♣\n"
            + "C11: J♣\n"
            + "C12: Q♣\n"
            + "C13: K♣\n"
            + "C14: A♦\n"
            + "C15: 2♦\n"
            + "C16: 3♦\n"
            + "C17: 4♦\n"
            + "C18: 5♦\n"
            + "C19: 6♦\n"
            + "C20: 7♦\n"
            + "C21: 8♦\n"
            + "C22: 9♦\n"
            + "C23: 10♦\n"
            + "C24: J♦\n"
            + "C25: Q♦\n"
            + "C26: K♦\n"
            + "C27: A♥\n"
            + "C28: 2♥\n"
            + "C29: 3♥\n"
            + "C30: 4♥\n"
            + "C31: 5♥\n"
            + "C32: 6♥\n"
            + "C33: 7♥\n"
            + "C34: 8♥\n"
            + "C35: 9♥\n"
            + "C36: 10♥\n"
            + "C37: J♥\n"
            + "C38: Q♥\n"
            + "C39: K♥\n"
            + "C40: A♠\n"
            + "C41: 2♠\n"
            + "C42: 3♠\n"
            + "C43: 4♠\n"
            + "C44: 5♠\n"
            + "C45: 6♠\n"
            + "C46: 7♠\n"
            + "C47: 8♠\n"
            + "C48: 9♠\n"
            + "C49: 10♠\n"
            + "C50: J♠\n"
            + "C51: Q♠\n"
            + "C52: K♠\n"
            + "C53:\n"
            + "Source Pile (F1, C2, O3, etc.): "
            + "Card Number: "
            +  "Destination Pile (F1, C2, O3, etc.): "
            + "Please give a valid pile input: \n"
            + "Game quit prematurely.");
  }
}
