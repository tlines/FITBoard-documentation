package cs3500.hw03;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.hw02.Card;
import cs3500.hw02.PileType;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;

/**
 * Created by Tim on 5/24/2017.
 */
public class FreecellController implements IFreecellController<Card> {
  private Appendable output;
  private Scanner in;

  /**
   * accepts and stores a readable object and an appendable object for doing input and output.
   * in the game, whenever a user input is required, the readable object will be used, and whenever
   * an output must be transmitted, the appendable object will be used. calls helper to initialize
   * a game, using user input.
   *
   * @param rd input
   * @param ap output
   */
  public FreecellController(Readable rd, Appendable ap) {
    Readable input;
    if (rd == null) {
      throw new IllegalStateException("Readable is null.");
    }
    if (ap == null) {
      throw new IllegalStateException("Appendable is null.");
    }
    input = rd;
    this.output = ap;
    this.in = new Scanner(input);
  }

  /**
   * will take in user input to initialize the game with given cascade pile
   * and open pile counts, and whether they want the deck to be shuffled or not.
   */
  public void initGame() {
    try {
      String s;
      output.append("Number of Cascade Piles: ");
      int numCascade;
      do {
        while (!in.hasNextInt()) {
          s = in.next();
          if (s.equalsIgnoreCase("q")) {
            output.append("\nGame quit prematurely.");
            return;
          }
          output.append("Please provide a number greater than or equal to 4: ");
        }
        numCascade = in.nextInt();
        if (numCascade < 4) {
          output.append("Please provide a number greater than or equal to 4: ");
        }
      }
      while (numCascade < 4);


      output.append("Number of Open Piles: ");
      int numOpen;
      do {
        while (!in.hasNextInt()) {
          s = in.next();
          if (s.equalsIgnoreCase("q")) {
            output.append("\nGame quit prematurely.");
            return;
          }
          output.append("Please provide a number greater than or equal to 1: ");
        }
        numOpen = in.nextInt();
        if (numOpen < 1) {
          output.append("Please provide a number greater than or equal to 1: ");
        }
      }
      while (numOpen < 1);

      boolean shuffle;
      boolean yorn = false;
      output.append("Would you like to shuffle? (y/n): ");
      do {
        s = in.next();
        if (s.equalsIgnoreCase("q")) {
          output.append("\nGame quit prematurely.");
          return;
        }
        if (!s.equalsIgnoreCase("y") && !s.equalsIgnoreCase("n")) {
          output.append("Please just type a 'y' or an 'n': ");
        }
        shuffle = (s.toLowerCase().equals("y"));
        yorn = (shuffle || s.toLowerCase().equals("n"));
      }
      while (!yorn);

      FreecellModel model = new FreecellModel();
      List<Card> deck = model.getDeck();
      playGame(deck, model, numCascade, numOpen, shuffle);
    } catch (IOException ignored) {
      // at this point, we're done with the void method, so since i was goig to return, anyway,
      // i don't actually need to put anything her if i call the exception ignored.
    }
  }

  @Override
  public void playGame(List<Card> deck, FreecellOperations<Card> model, int numCascades,
                       int numOpens, boolean shuffle) throws IllegalStateException {
    /**
     * plays a game. asks the provided model to start a game with the provided parameters, then
     * runs the game in the following sequence until the game is over:
     * a) transmit game state to the appendable object exactly as the model provides it.
     * b) if the game is ongoing, wait for user input from the readable object. a valid user input
     * for a move is a sequence of three inputs (separated by spaces or newlines):
     * i. the source pile (1-indexed).
     * ii. the card index (1-indexed).
     * iii. the destination pile, (1-indexed).
     * the controller will parse these inputs and pass the information on to the model to make
     * the move.
     * c. if the game has been won, the method should transmit the final game state, and a message
     * "Game over." on a new line and return.
     */

    if (deck == null) {
      throw new IllegalArgumentException("Deck is null.");
    }
    if (model == null) {
      throw new IllegalArgumentException("Model is null.");
    }

    try {
      model.startGame(deck, numCascades, numOpens, shuffle);
    } catch (IllegalArgumentException e) {
      try {
        output.append("Could not start game.");
        return;
      } catch (IOException e1) {
        return;
      }
    }

    try {
      output.append("\n");
      output.append(model.getGameState());
      output.append("\n");
    } catch (IOException e) {
      return;
    }

    while (!model.isGameOver()) {
      Movable move = new Movable();
      try {
        output.append("Source Pile (F1, C2, O3, etc.): ");
        String s = in.next();
        while (!validFormat(s, true)
                || (s.charAt(0) == 'C'
                && Integer.parseInt(s.substring(1)) > numCascades)
                || (s.charAt(0) == 'O'
                && Integer.parseInt(s.substring(1)) > numOpens)
                || (s.charAt(0) == 'F'
                && Integer.parseInt(s.substring(1)) > 4)) {
          if (s.equalsIgnoreCase("q")) {
            return;
          }
          output.append("Please give a valid pile input: ");
          s = in.next();
        }
        move.setSource(charToPileType(s.charAt(0)));
        move.setPileNumber(Integer.parseInt(s.substring(1)) - 1);

        output.append("Card Number: ");
        s = in.next();
        while (!validFormat(s, false)
                // can't figure out how to find if a card exists at index.
                || ((move.getSource() == PileType.CASCADE)
                && model.getPile(PileType.CASCADE).get(move.getPileNumber())
                .get(Integer.parseInt(s.substring(0)) - 1) == null)
                || ((move.getSource() == PileType.OPEN)
                && model.getPile(PileType.OPEN).get(move.getPileNumber())
                .get(Integer.parseInt(s.substring(0)) - 1) == null)
                || ((move.getSource() == PileType.FOUNDATION)
                && model.getPile(PileType.FOUNDATION).get(move.getPileNumber())
                .get(Integer.parseInt(s.substring(0)) - 1) == null)) {
          if (s.equalsIgnoreCase("q")) {
            return;
          }
          output.append("Please give a valid card number: ");
          s = in.next();
        }
        move.setCardIndex(Integer.parseInt(s) - 1);

        output.append("Destination Pile (F1, C2, O3, etc.): ");
        s = in.next();
        while (!validFormat(s, true)
                || (s.charAt(0) == 'C'
                && Integer.parseInt(s.substring(1)) > numCascades)
                || (s.charAt(0) == 'O'
                && Integer.parseInt(s.substring(1)) > numOpens)
                || (s.charAt(0) == 'F'
                && Integer.parseInt(s.substring(1)) > 4)) {
          if (s.equalsIgnoreCase("q")) {
            return;
          }
          output.append("Please give a valid pile input: ");
          s = in.next();
        }
        move.setDestination(charToPileType(s.charAt(0)));
        move.setDestPileNumber(Integer.parseInt(s.substring(1)) - 1);

        try {
          model.move(move.getSource(), move.getPileNumber(), move.getCardIndex(),
                  move.getDestination(), move.getDestPileNumber());
        } catch (IllegalArgumentException e) {
          output.append(String.format("\nInvalid move. Try again. %s \n", e.getMessage()));
        }

        output.append("\n");
        output.append(model.getGameState());
        output.append("\n");
        if (model.isGameOver()) {
          output.append("Game over.");
        }
      } catch (IOException e) {
        return;
      }
    }
  }

  /**
   * checks if an input is valid, this can apply to either a pile or an index.
   * if it's a pile, return false if it doesn't start with 'C', 'F', or 'O'.
   * if it starts with 'q' or 'Q', a message will appear saying the game has
   * quit, and we will end the game when we return to the playGame method.
   * if it's an index, return false if the number given isn't greater
   * than 0 (they're 1 indexed). we can tell if we're talking about a pile or
   * index using the isPile boolean.
   *
   * @param string input string from user specifying a pile or an index.
   * @param isPile input string can be a pile or an index. this bool tells you which one it is.
   * @return true if the input is formatted properly, false if not.
   */
  private boolean validFormat(String string, boolean isPile) throws IOException {
    if (string.charAt(0) == 'q' || string.charAt(0) == 'Q') {
      output.append("\nGame quit prematurely.");
      return false;
    }
    int num;
    if (isPile) {
      // working with a pile
      if (string.length() < 2) {
        return false;
      }
      char pile = string.charAt(0);

      if (!(pile == 'C' || pile == 'O' || pile == 'F')) {
        return false;
      }

      num = Integer.parseInt(string.substring(1));
    } else {
      try {
        num = Integer.parseInt(string);
      } catch (NumberFormatException e) {
        return false;
      }
    }

    return (num > 0);
  }

  /**
   * converts a given char to a PileType.
   *
   * @param type first letter of the specified PileType
   * @return the full PileType
   * @throws IllegalArgumentException if the letter isn't 'F', 'C', or 'O'
   */
  private PileType charToPileType(char type) {
    switch (type) {
      case 'F':
        return PileType.FOUNDATION;
      case 'C':
        return PileType.CASCADE;
      case 'O':
        return PileType.OPEN;
      default:
        throw new IllegalArgumentException("Unknown PileType.");
    }
  }
}
