package cs3500.hw03;

import cs3500.hw02.PileType;



/**
 * Created by Tim on 5/25/2017.
 */
public class Movable {
  /**
   * a movable object. the parameters of the move function are
   * this function's fields. will hold info for a valid (or invalid)
   * move.
   */
  private PileType source;
  private int pileNumber;
  private int cardIndex;
  private PileType destination;
  private int destPileNumber;

  public PileType getSource() {
    return this.source;
  }

  public int getPileNumber() {
    return this.pileNumber;
  }

  public int getCardIndex() {
    return this.cardIndex;
  }

  public PileType getDestination() {
    return this.destination;
  }

  public int getDestPileNumber() {
    return this.destPileNumber;
  }

  public void setSource(PileType source) {
    this.source = source;
  }

  public void setPileNumber(int pileNumber) {
    this.pileNumber = pileNumber;
  }

  public void setCardIndex(int cardIndex) {
    this.cardIndex = cardIndex;
  }

  public void setDestination(PileType destination) {
    this.destination = destination;
  }

  public void setDestPileNumber(int destPileNumber) {
    this.destPileNumber = destPileNumber;
  }
}
