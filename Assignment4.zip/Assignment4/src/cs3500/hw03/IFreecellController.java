package cs3500.hw03;

import cs3500.hw02.FreecellOperations;
import java.util.List;

/**
 * Created by Tim on 5/24/2017.
 */
public interface IFreecellController<K> {
  /**
   * start a new game of Freecell using the provided model, number of cascade and open piles and
   * the provided deck. if the shuffle parameter is false the deck will be used as-is. otherwise,
   * the deck will be shuffled.
   * @param deck deck of 52 cards given, could already be shuffled.
   * @param model FreecellOperations model given.
   * @param numCascades number of cascade piles given.
   * @param numOpens number of open piles given.
   * @param shuffle boolean that decides whether the deck should be shuffled again.
   * @throws IllegalStateException if the controller has not been initialized properly.
   */
  void playGame(List<K> deck, FreecellOperations<K> model, int numCascades, int numOpens,
                boolean shuffle) throws IllegalStateException;
}
