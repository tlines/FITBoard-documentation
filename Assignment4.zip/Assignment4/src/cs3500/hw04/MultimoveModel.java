package cs3500.hw04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cs3500.hw02.FreecellOperations;
import cs3500.hw02.Card;
import cs3500.hw02.FreecellModel;
import cs3500.hw02.PileType;
import cs3500.hw02.Suit;

/**
 * Created by Tim on 6/1/2017.
 * Does everything a FreecellModel does, but now with multiple moves!
 */
public class MultimoveModel extends FreecellModel implements FreecellOperations<Card> {
  @Override
  public ArrayList<ArrayList<Card>> getPile(PileType pile) {
    if (pile == PileType.CASCADE) {
      return cascade;
    }
    if (pile == PileType.FOUNDATION) {
      return foundation;
    }
    if (pile == PileType.OPEN) {
      return open;
    } else {
      throw new IllegalArgumentException("Invalid pile type.");
    }
  }

  /**
   * same as freecellmodel.
   * @return ordered deck of cards.
   */
  @Override
  public List<Card> getDeck() {
    List<Card> deck = new ArrayList<>(52);

    for (Suit suit : Suit.values()) {
      for (int value = 1; value < 14; value++) {
        Card c = new Card(value, suit);
        deck.add(c);
      }
    }
    return deck;
  }

  /**
   * same as in freecellmodel
   *
   * @param deck            the deck to be dealt
   * @param numCascadePiles number of cascade piles
   * @param numOpenPiles    number of open piles
   * @param shuffle         if true, shuffle the deck else deal the deck as-is
   * @throws IllegalArgumentException probably never.
   */
  @Override
  public void startGame(List<Card> deck, int numCascadePiles, int numOpenPiles, boolean shuffle)
          throws IllegalArgumentException {
    validateEverything(deck, numCascadePiles, numOpenPiles);

    cascade = new ArrayList<>();
    foundation = new ArrayList<>();
    open = new ArrayList<>();

    for (int i = 0; i < 4; i++) {
      foundation.add(new ArrayList<>());
    }
    for (int i = 0; i < numOpenPiles; i++) {
      open.add(new ArrayList<>());
    }
    for (int i = 0; i < numCascadePiles; i++) {
      cascade.add(new ArrayList<>());
    }

    if (shuffle) {
      Collections.shuffle(deck);
    }

    for (int i = 0; i < 52; i++) {
      Card card = deck.get(i);
      cascade.get(i % numCascadePiles).add(card);
    }
  }

  /**
   * counts the number of empty open piles.
   * @return number of empty open piles.
   */
  private int freeOpens() {
    int num = 0;
    for (ArrayList<Card> p : open) {
      if (p.isEmpty()) {
        num++;
      }
    }
    return num;
  }

  /**
   * counts the number of empty cascade piles.
   * @return number of empty cascade piles.
   */
  private int freeCascades() {
    int num = 0;
    for (ArrayList<Card> p : cascade) {
      if (p.isEmpty()) {
        num++;
      }
    }
    return num;
  }

  /**
   * moves all cards in front of the card at cardindex with it when it's moved to another
   * cascade pile.
   * @param pileNumber cascade pile card is taken from.
   * @param cardIndex index in cascade pile where the card can be found.
   * @param destPileNumber cascade pile where the card is being moved.
   */
  private void moveCtoC(int pileNumber, int cardIndex, int destPileNumber) {
    if (cascade.get(pileNumber).size() - cardIndex > (freeOpens() + 1)
            * (int)Math.pow(2, freeCascades())) {
      throw new IllegalArgumentException("Can't move that many cards");
    }
    for (int n = 0; cardIndex + n < cascade.get(pileNumber).size(); n++) {
      if (n == 0) {
        if (!validFromAny(cascade, pileNumber, cardIndex)
                || !validToC(cascade, pileNumber, cardIndex, destPileNumber)) {
          throw new IllegalArgumentException("First card is an invalid move.");
        }
      }
      else if (cascade.get(pileNumber).get(cardIndex + n - 1).getColor().equals(
              cascade.get(pileNumber).get(cardIndex + n).getColor())
              || cascade.get(pileNumber).get(cardIndex + n - 1).getValue()
              != cascade.get(pileNumber).get(cardIndex + n).getValue() + 1) {
        throw new IllegalArgumentException("One or more cards can't make that move.");
      }
    }
    int originalsize = cascade.get(pileNumber).size();
    for (int i = 0; cardIndex + i < originalsize; i++) {
      Card card = cascade.get(pileNumber).get(cardIndex);
      cascade.get(destPileNumber).add(card);
      cascade.get(pileNumber).remove(card);
    }
  }

  /**
   * should be the same as the freecellmodel, except for when moving from cascade to cascade.
   * in this case, we can select an index that is greater than 0 and move it and the cards
   * on top of it.
   *
   * @param source         the type of the source pile see @link{PileType}
   * @param pileNumber     the pile number of the given type, starting at 0
   * @param cardIndex      the index of the card to be moved from the source
   *                       pile, starting at 0
   * @param destination    the type of the destination pile (see
   * @param destPileNumber the pile number of the given type, starting at 0
   * @throws IllegalArgumentException if a move is invalid
   */
  @Override
  public void move(PileType source, int pileNumber, int cardIndex, PileType destination,
                   int destPileNumber) throws IllegalArgumentException {
    switch (source) {
      case OPEN:
        if (cardIndex != open.get(pileNumber).size() - 1) {
          throw new IllegalArgumentException("Can only move one card at a time.");
        }
        switch (destination) {
          case OPEN:
            moveOtoO(pileNumber, destPileNumber);
            break;
          case CASCADE:
            moveOtoC(pileNumber, destPileNumber);
            break;
          case FOUNDATION:
            moveOtoF(pileNumber, destPileNumber);
            break;
          default:
            throw new IllegalArgumentException("Move not valid");
        }
        break;
      case CASCADE:
        switch (destination) {
          case OPEN:
            if (cardIndex != cascade.get(pileNumber).size() - 1) {
              throw new IllegalArgumentException("Can only move one card at a time.");
            }
            moveCtoO(pileNumber, cardIndex, destPileNumber);
            break;
          case CASCADE:
            if (cardIndex < 0 || cardIndex >= cascade.get(pileNumber).size()) {
              throw new IndexOutOfBoundsException("Card index out of bounds.");
            }
            moveCtoC(pileNumber, cardIndex, destPileNumber);
            break;
          case FOUNDATION:
            if (cardIndex != cascade.get(pileNumber).size() - 1) {
              throw new IllegalArgumentException("Can only move one card at a time.");
            }
            moveCtoF(pileNumber, cardIndex, destPileNumber);
            break;
          default:
            throw new IllegalArgumentException("Move not valid");
        }
        break;
      case FOUNDATION:
        if (cardIndex != foundation.get(pileNumber).size() - 1) {
          throw new IllegalArgumentException("Can only move one card at a time.");
        }
        switch (destination) {
          case OPEN:
            moveFtoO(pileNumber, cardIndex, destPileNumber);
            break;
          case CASCADE:
            moveFtoC(pileNumber, cardIndex, destPileNumber);
            break;
          case FOUNDATION:
            moveFtoF(pileNumber, cardIndex, destPileNumber);
            break;
          default:
            throw new IllegalArgumentException("Move not valid");
        }
        break;
      default:
        throw new IllegalArgumentException("Move not valid");
    }
  }

  /**
   * same as in freecellmodel.
   *
   * @return true if the top card in each foundation pile is a king
   */
  @Override
  public boolean isGameOver() {
    for (int i = 0; i < 4; i++) {
      if (foundation.get(i).isEmpty()
              || foundation.get(i).get(foundation.get(i).size() - 1).getValue() != 13) {
        return false;
      }
    }
    return true;
  }

  /**
   * same as in freecellmodel
   * @return string that shows what the current game board looks like.
   */
  @Override
  public String getGameState() {
    if (cascade == null) {
      return "";
    }

    StringBuilder output = new StringBuilder();

    for (int i = 0; i < foundation.size(); i++) {
      output.append("F");
      output.append(i + 1);
      output.append(":");

      for (int j = 0; j < foundation.get(i).size(); j++) {
        output.append(" ");
        output.append(foundation.get(i).get(j).toString());

        if (j < foundation.get(i).size() - 1) {
          output.append(",");
        }
      }

      output.append("\n");
    }

    for (int i = 0; i < open.size(); i++) {
      output.append("O");
      output.append(i + 1);
      output.append(":");
      if (!open.get(i).isEmpty()) {
        output.append(" ");
        output.append(open.get(i).get(0).toString());
      }
      output.append("\n");
    }

    for (int i = 0; i < cascade.size(); i++) {
      output.append("C");
      output.append(i + 1);
      output.append(":");

      for (int j = 0; j < cascade.get(i).size(); j++) {
        output.append(" ");
        output.append(cascade.get(i).get(j).toString());

        if (j < cascade.get(i).size() - 1) {
          output.append(",");
        }
      }

      if (i != cascade.size() - 1) {
        output.append("\n");
      }
    }

    return output.toString();
  }
}
