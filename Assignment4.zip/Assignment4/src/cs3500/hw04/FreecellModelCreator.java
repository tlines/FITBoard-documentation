package cs3500.hw04;

import cs3500.hw02.FreecellModel;
import cs3500.hw02.FreecellOperations;

/**
 * Created by Tim on 6/1/2017.
 * Contains a public enum GameType with two possible values SINGLEMOVE AND MULTIMOVE.
 * Contains a static factor method create(GameType type) that returns either a FreecellModel
 * or MultimoveModel, depending on the value of the parameter.
 */
public class FreecellModelCreator {
  /**
   * default constructor.
   */
  public FreecellModelCreator() {
    // nothing to initialize, just creating a freecellmodelcreator
  }

  /**
   * takes in a gametype and returns the model corresponding to it.
   * @param type type of game we want to play, single move or multi move.
   * @return either freecellmodel or multimove model, both are freecelloperations.
   */
  public static FreecellOperations create(GameType type) {
    switch (type) {
      case SINGLEMOVE:
        return new FreecellModel();
      case MULTIMOVE:
        return new MultimoveModel();
      default:
        throw new IllegalArgumentException("Invalid game type.");
    }
  }

  /**
   * represents both game types.
   */
  public enum GameType {
    SINGLEMOVE, MULTIMOVE
  }
}
