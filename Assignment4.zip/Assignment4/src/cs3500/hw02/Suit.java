package cs3500.hw02;

/**
 * Created by Tim on 5/17/2017.
 */
public enum Suit {
  /**
   * represents a suit of a card, this can be a club, diamond, heart, or spade.
   * depending on which it is, the to string method in card will convert it to the corresponding
   * symbol.
   */
  CLUBS, DIAMONDS, HEARTS, SPADES
}