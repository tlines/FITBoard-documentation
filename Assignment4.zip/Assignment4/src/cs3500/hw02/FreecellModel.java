package cs3500.hw02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Tim on 5/16/2017.
 * A single move game model. Changed a lot of stuff to hopefully finally get the
 * game working.
 */
public class FreecellModel implements FreecellOperations<Card> {
  /**
   * three different types of files.
   * Change: made them protected, so MultimoveModel could use them.
   */
  protected ArrayList<ArrayList<Card>> cascade;
  protected ArrayList<ArrayList<Card>> foundation;
  protected ArrayList<ArrayList<Card>> open;

  /**
   * default constructor for a freecellmodel.
   */
  public FreecellModel() {
    cascade = new ArrayList<>();
    foundation = new ArrayList<>();
    open = new ArrayList<>();
  }

  /* Change: These are never used.
  public ArrayList<ArrayList<Card>> getCascade() {
    return cascade;
  }

  public ArrayList<ArrayList<Card>> getFoundation() {
    return foundation;
  }

  public ArrayList<ArrayList<Card>> getOpen() {
    return open;
  }
  */

  /**
   * puts all suits in proper order in the foundation piles.
   */
  public void finishGame() {
    for (Suit suit : Suit.values()) {
      for (int value = 1; value < 14; value++) {
        if (suit == Suit.CLUBS) {
          foundation.get(0).add(new Card(value, suit));
        } else if (suit == Suit.DIAMONDS) {
          foundation.get(1).add(new Card(value, suit));
        } else if (suit == Suit.HEARTS) {
          foundation.get(2).add(new Card(value, suit));
        } else if (suit == Suit.SPADES) {
          foundation.get(3).add(new Card(value, suit));
        } else {
          throw new IllegalArgumentException("Invalid suit");
        }
      }
    }
  }

  @Override
  public ArrayList<ArrayList<Card>> getPile(PileType pile) {
    if (pile == PileType.CASCADE) {
      return cascade;
    }
    if (pile == PileType.FOUNDATION) {
      return foundation;
    }
    if (pile == PileType.OPEN) {
      return open;
    } else {
      throw new IllegalArgumentException("Invalid pile type.");
    }
  }

  @Override
  public List<Card> getDeck() {
    List<Card> deck = new ArrayList<>(52);

    for (Suit suit : Suit.values()) {
      for (int value = 1; value < 14; value++) {
        Card c = new Card(value, suit);
        deck.add(c);
      }
    }
    return deck;
  }

  /**
   * NEW: will return a set containing one of every card in the deck. if this is less than
   * 52 cards, we had duplicates.
   * @param deck deck being checked for duplicates.
   * @return list of all cards in deck, removing duplicates.
   */
  private ArrayList<Card> findDuplicates(List<Card> deck) {
    ArrayList<Card> output = new ArrayList<>();
    ArrayList<Card> set = new ArrayList<>();

    for (Card card : deck) {
      for (Card dup : set) {
        if (card.getValue() == dup.getValue()
                && card.getSuit().equals(dup.getSuit())) {
          output.add(card);
          return output;
        }
      }
      set.add(card);
    }
    return output;
  }

  /**
   * Change: made protected so MultimoveModel could use it.
   * will check if the deck has been created. if so, does it have the proper number of cards?
   * will also check that the number of piles is correct for cascade and open piles, because users
   * can change those.
   */
  protected void validateEverything(List<Card> deck, int numCascadePiles, int numOpenPiles) {
    if (deck == null) {
      throw new NullPointerException("Deck is null");
    }
    if (numCascadePiles < 4) {
      throw new IllegalArgumentException("Number of cascade piles must be at least 4");
    }
    if (numOpenPiles < 1) {
      throw new IllegalArgumentException("Number of open piles must be at least 1");
    }

    ArrayList<Card> set = findDuplicates(deck);

    if (set.size() > 0) {
      throw new IllegalArgumentException("Deck contains duplicates");
    }
    if (deck.size() != 52) {
      throw new IllegalArgumentException("Deck should have 52 cards");
    }
  }

  /**
   * disperses cards to each pile and initializes piles.
   * @param deck            the deck to be dealt
   * @param numCascadePiles number of cascade piles
   * @param numOpenPiles    number of open piles
   * @param shuffle         if true, shuffle the deck else deal the deck as-is
   * @throws IllegalArgumentException probably never.
   */
  @Override
  public void startGame(List<Card> deck, int numCascadePiles, int numOpenPiles, boolean shuffle)
          throws IllegalArgumentException {
    validateEverything(deck, numCascadePiles, numOpenPiles);

    cascade = new ArrayList<>();
    foundation = new ArrayList<>();
    open = new ArrayList<>();

    for (int i = 0; i < 4; i++) {
      foundation.add(new ArrayList<>());
    }
    for (int i = 0; i < numOpenPiles; i++) {
      open.add(new ArrayList<>());
    }
    for (int i = 0; i < numCascadePiles; i++) {
      cascade.add(new ArrayList<>());
    }

    if (shuffle) {
      Collections.shuffle(deck);
    }

    for (int i = 0; i < 52; i++) {
      Card card = deck.get(i);
      cascade.get(i % numCascadePiles).add(card);
    }
  }

  /**
   * Change: cleaned up move and made helpers to hopefully have it make more sense. This also
   * fixed a couple of movement problems.
   */

  /**
   * can only return true if the source pile has a card at the given position, otherwise an
   * error will be thrown.
   *
   * @param pile one of the three ArrayListArrayListCards that we are taking the card from
   * @param pileNumber index of the open source pile
   * @param cardIndex index of the card in the ArrayList
   * @return true if source pile has a card
   */
  protected boolean validFromAny(ArrayList<ArrayList<Card>> pile, int pileNumber, int cardIndex) {
    if (pile.get(pileNumber).isEmpty() || pileNumber < 0 || pileNumber >= pile.size()) {
      throw new IllegalArgumentException("Source pile is empty or nonexistant.");
    }
    if (pile.get(pileNumber).get(cardIndex) == null) {
      throw new IllegalArgumentException("Card doesn't exist.");
    }
    return true;
  }

  /**
   * can only return true if the open pile doesn't have a card in it, and is within
   * the range of the number of open piles specified.
   *
   * @param destPileNumber index of the open destination pile
   * @return true if the destination pile is empty, and within the number of open piles
   */
  protected boolean validToO(int destPileNumber) {
    if (destPileNumber < 0
            || destPileNumber >= open.size()
            || !open.get(destPileNumber).isEmpty()) {
      throw new IllegalArgumentException("Moving to a full or nonexistant"
              + " open destination pile.");
    }
    return true;
  }

  /**
   * check if the destination pile is empty and the card being moved is anything
   * before moving, if not, check that the card being moved is one less than and of the
   * opposite color of the top card in the destination pile, then move.
   *
   * @param pile one of the three ArrayListArrayListCards that is the source of the card
   * @param pileNumber the ArrayListCard in which the card is found
   * @param cardIndex the index in the pileNumber where the card is found
   * @param destPileNumber index of the cascade destination pile
   * @return true if the pile is empty, or the card being moved is of different color and one
   *         less than the card to be above it.
   */
  protected boolean validToC(ArrayList<ArrayList<Card>> pile, int pileNumber,
                           int cardIndex, int destPileNumber) {
    if (destPileNumber < 0 || destPileNumber >= cascade.size()) {
      throw new IllegalArgumentException("Moving to a nonexistant cascade destination"
              + " pile.");
    }
    return (cascade.get(destPileNumber).isEmpty()
            || (!pile.get(pileNumber).get(cardIndex).getColor().equals(
            cascade.get(destPileNumber).get(cascade.get(destPileNumber).size() - 1)
                    .getColor())
            && (pile.get(pileNumber).get(cardIndex).getValue()
            == cascade.get(destPileNumber).get(cascade.get(destPileNumber).size() - 1)
                    .getValue() - 1)));
  }

  /**
   * check if the destination pile is empty and the card being moved is an ace
   * before moving, if not, check that the card being moved is one more than and of the
   * same suit as the top card in the destination pile, then move.
   *
   * @param pile one of the three ArrayListArrayListCards that is the source of the card
   * @param pileNumber the ArrayListCard in which the card is found
   * @param cardIndex the index in the pileNumber where the card is found
   * @param destPileNumber index of the cascade destination pile
   * @return true if the pile is empty, or the card being moved is of the same suit and one
   *         more than the card to be above it.
   */
  protected boolean validToF(ArrayList<ArrayList<Card>> pile, int pileNumber,
                           int cardIndex, int destPileNumber) {
    if (destPileNumber < 0 || destPileNumber >= foundation.size()) {
      throw new IllegalArgumentException("Moving to a nonexistant foundation destination"
              + " pile.");
    }
    return (foundation.get(destPileNumber).isEmpty()
            && pile.get(pileNumber).get(cardIndex).getValue() == 1)
            || (!foundation.get(destPileNumber).isEmpty()
            && pile.get(pileNumber).get(cardIndex).getSuit().equals(
            foundation.get(destPileNumber).get(foundation.get(destPileNumber).size() - 1)
                    .getSuit())
            && (pile.get(pileNumber).get(cardIndex).getValue()
            == foundation.get(destPileNumber).get(foundation.get(destPileNumber).size() - 1)
                    .getValue() + 1));
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, make sure the destination pile is empty before moving, if not, throw
   * an exception.
   *
   * @param pileNumber source open pile index we're moving a card from
   * @param destPileNumber destination open pile index we're moving a card to
   */
  protected void moveOtoO(int pileNumber, int destPileNumber) {
    if (validFromAny(open, pileNumber, 0) && validToO(destPileNumber)) {
      Card card = open.get(pileNumber).get(0);
      open.get(destPileNumber).add(card);
      open.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a cascade is valid, then move.
   *
   * @param pileNumber source open pile index we're moving a card from
   * @param destPileNumber destination cascade pile index we're moving a card to
   */
  protected void moveOtoC(int pileNumber, int destPileNumber) {
    if (validFromAny(open, pileNumber, 0)
            && validToC(open, pileNumber, 0, destPileNumber)) {
      Card card = open.get(pileNumber).get(0);
      cascade.get(destPileNumber).add(card);
      open.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a foundation is valid then move.
   *
   * @param pileNumber open pile card should be in
   * @param destPileNumber foundation pile the card should be moved to
   */
  protected void moveOtoF(int pileNumber, int destPileNumber) {
    if (validFromAny(open, pileNumber, 0)
            && validToF(open, pileNumber, 0, destPileNumber)) {
      Card card = open.get(pileNumber).get(0);
      foundation.get(destPileNumber).add(card);
      open.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a open is valid then move.
   *
   * @param pileNumber cascade pile number in which the card can be found
   * @param cardIndex index in the arraylist where the card can be found
   * @param destPileNumber destination open pile where the card will be moved
   */
  protected void moveCtoO(int pileNumber, int cardIndex, int destPileNumber) {
    if (validFromAny(cascade, pileNumber, cardIndex)
            && validToO(destPileNumber)) {
      Card card = cascade.get(pileNumber).get(cardIndex);
      open.get(destPileNumber).add(card);
      cascade.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a cascade is valid then move.
   *
   * @param pileNumber cascade pile number in which the card can be found
   * @param cardIndex index in the arraylist where the card can be found
   * @param destPileNumber destination cascade pile where the card will be moved
   */
  private void moveCtoC(int pileNumber, int cardIndex, int destPileNumber) {
    if (validFromAny(cascade, pileNumber, cardIndex)
            && validToC(cascade, pileNumber, cardIndex, destPileNumber)) {
      Card card = cascade.get(pileNumber).get(cardIndex);
      cascade.get(destPileNumber).add(card);
      cascade.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a foundation is valid then move.
   *
   * @param pileNumber cascade pile number in which the card can be found
   * @param cardIndex index in the arraylist where the card can be found
   * @param destPileNumber destination foundation pile where the card will be moved
   */
  protected void moveCtoF(int pileNumber, int cardIndex, int destPileNumber) {
    if (validFromAny(cascade, pileNumber, cardIndex)
            && validToF(cascade, pileNumber, cardIndex, destPileNumber)) {
      Card card = cascade.get(pileNumber).get(cardIndex);
      foundation.get(destPileNumber).add(card);
      cascade.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a open is valid then move.
   *
   * @param pileNumber foundation pile number in which the card can be found
   * @param cardIndex index in the arraylist where the card can be found
   * @param destPileNumber destination open pile where the card will be moved
   */
  protected void moveFtoO(int pileNumber, int cardIndex, int destPileNumber) {
    if (validFromAny(foundation, pileNumber, cardIndex)
            && validToO(destPileNumber)) {
      Card card = foundation.get(pileNumber).get(cardIndex);
      open.get(destPileNumber).add(card);
      foundation.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a foundation is valid then move.
   *
   * @param pileNumber foundation pile number in which the card can be found
   * @param cardIndex index in the arraylist where the card can be found
   * @param destPileNumber destination cascade pile where the card will be moved
   */
  protected void moveFtoC(int pileNumber, int cardIndex, int destPileNumber) {
    if (validFromAny(foundation, pileNumber, cardIndex)
            && validToC(foundation, pileNumber, cardIndex, destPileNumber)) {
      Card card = foundation.get(pileNumber).get(cardIndex);
      cascade.get(destPileNumber).add(card);
      foundation.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * check if there's a card in the source pile, if there isn't, throw an exception
   * if there is, check if the move to a foundation is valid then move.
   *
   * @param pileNumber foundation pile number in which the card can be found
   * @param cardIndex index in the arraylist where the card can be found
   * @param destPileNumber destination foundation pile where the card will be moved
   */
  protected void moveFtoF(int pileNumber, int cardIndex, int destPileNumber) {
    if (validFromAny(foundation, pileNumber, cardIndex)
            && validToF(foundation, pileNumber, cardIndex, destPileNumber)) {
      Card card = foundation.get(pileNumber).get(cardIndex);
      foundation.get(destPileNumber).add(card);
      foundation.get(pileNumber).remove(card);
    }
    else {
      throw new IllegalArgumentException("Invalid move.");
    }
  }

  /**
   * move a single card from one pile to another.
   *
   * @param source         the type of the source pile see @link{PileType}
   * @param pileNumber     the pile number of the given type, starting at 0
   * @param cardIndex      the index of the card to be moved from the source
   *                       pile, starting at 0
   * @param destination    the type of the destination pile (see
   * @param destPileNumber the pile number of the given type, starting at 0
   * @throws IllegalArgumentException if invalid move
   */
  @Override
  public void move(PileType source, int pileNumber, int cardIndex, PileType destination,
                   int destPileNumber) throws IllegalArgumentException {
    switch (source) {
      case OPEN:
        if (cardIndex != open.get(pileNumber).size() - 1) {
          throw new IllegalArgumentException("Can only move one card at a time.");
        }
        switch (destination) {
          case OPEN:
            moveOtoO(pileNumber, destPileNumber);
            break;
          case CASCADE:
            moveOtoC(pileNumber, destPileNumber);
            break;
          case FOUNDATION:
            moveOtoF(pileNumber, destPileNumber);
            break;
          default:
            throw new IllegalArgumentException("Move not valid");
        }
        break;
      case CASCADE:
        if (cardIndex != cascade.get(pileNumber).size() - 1) {
          throw new IllegalArgumentException("Can only move one card at a time.");
        }
        switch (destination) {
          case OPEN:
            moveCtoO(pileNumber, cardIndex, destPileNumber);
            break;
          case CASCADE:
            moveCtoC(pileNumber, cardIndex, destPileNumber);
            break;
          case FOUNDATION:
            moveCtoF(pileNumber, cardIndex, destPileNumber);
            break;
          default:
            throw new IllegalArgumentException("Move not valid");
        }
        break;
      case FOUNDATION:
        if (cardIndex != foundation.get(pileNumber).size() - 1) {
          throw new IllegalArgumentException("Can only move one card at a time.");
        }
        switch (destination) {
          case OPEN:
            moveFtoO(pileNumber, cardIndex, destPileNumber);
            break;
          case CASCADE:
            moveFtoC(pileNumber, cardIndex, destPileNumber);
            break;
          case FOUNDATION:
            moveFtoF(pileNumber, cardIndex, destPileNumber);
            break;
          default:
            throw new IllegalArgumentException("Move not valid");
        }
        break;
      default:
        throw new IllegalArgumentException("Move not valid");
    }
  }

  /**
   * returns true if the top card in each foundation pile is a king.
   *
   * @return true if the top card in each foundation pile is a king
   */
  @Override
  public boolean isGameOver() {
    for (int i = 0; i < 4; i++) {
      if (foundation.get(i).isEmpty()
              || foundation.get(i).get(foundation.get(i).size() - 1).getValue() != 13) {
        return false;
      }
    }
    return true;
  }

  /**
   * return a string that shows what the board looks like.
   * @return string that shows what the current game board looks like.
   */
  @Override
  public String getGameState() {
    if (cascade == null) {
      return "";
    }

    StringBuilder output = new StringBuilder();

    for (int i = 0; i < foundation.size(); i++) {
      output.append("F");
      output.append(i + 1);
      output.append(":");

      for (int j = 0; j < foundation.get(i).size(); j++) {
        output.append(" ");
        output.append(foundation.get(i).get(j).toString());

        if (j < foundation.get(i).size() - 1) {
          output.append(",");
        }
      }

      output.append("\n");
    }

    for (int i = 0; i < open.size(); i++) {
      output.append("O");
      output.append(i + 1);
      output.append(":");
      if (!open.get(i).isEmpty()) {
        output.append(" ");
        output.append(open.get(i).get(0).toString());
      }
      output.append("\n");
    }

    for (int i = 0; i < cascade.size(); i++) {
      output.append("C");
      output.append(i + 1);
      output.append(":");

      for (int j = 0; j < cascade.get(i).size(); j++) {
        output.append(" ");
        output.append(cascade.get(i).get(j).toString());

        if (j < cascade.get(i).size() - 1) {
          output.append(",");
        }
      }

      if (i != cascade.size() - 1) {
        output.append("\n");
      }
    }

    return output.toString();
  }
}