package cs3500.hw02;

/**
 * Created by Tim on 5/17/2017.
 */
public class Card {
  /**
   * a card has a value from 1 to 13, and is part of a one of four suits. these suits can be two
   * colors.
   */
  private final int value;
  private final Suit suit;
  private String color;

  /**
   * constructor for a card.
   */
  public Card(int value, Suit suit) {
    this.value = value;
    this.suit = suit;

    if (suit == Suit.CLUBS || suit == Suit.SPADES) {
      this.color = "BLACK";
    }
    else {
      this.color = "RED";
    }
  }

  public int getValue() {
    return value;
  }

  public String getColor() {
    return color;
  }

  public String getSuit() {
    return suit.toString();
  }

  /**
   * Converts the card value and suit to the format specified.
   * @return formatted string saying what card it is.
   */
  public String toString() {
    StringBuilder output = new StringBuilder();
    switch (value) {
      case 1:
        output.append("A");
        break;
      case 11:
        output.append("J");
        break;
      case 12:
        output.append("Q");
        break;
      case 13:
        output.append("K");
        break;
      default:
        output.append(value);
    }
    switch (suit.toString()) {
      case "CLUBS":
        output.append("♣");
        break;
      case "DIAMONDS":
        output.append("♦");
        break;
      case "HEARTS":
        output.append("♥");
        break;
      case "SPADES":
        output.append("♠");
        break;
      default:
        throw new IllegalArgumentException("not a valid suit.");
    }
    return output.toString();
  }
}
